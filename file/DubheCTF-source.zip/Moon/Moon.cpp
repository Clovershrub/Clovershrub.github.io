﻿#include <iostream>

using namespace std;

struct BigNumber
{
	char* data = 0;
	int len = 0;
};

BigNumber prime, mod, zero, one, two;

#include "HyperCalculate.h"

char PrimeData[120] = "9809487348681152331029819565408456511798865503406106376596767981471065721835116695662903192838851317351";
char S[120] = "966067065041312779525914522335744036582325338752135670579530314774310672767303825382490093335255057";
char B[120] = "521238065732870249652703800453091708475401522884217498717772529962632921628576141779210985224958786535";
char AnsData[120] = "099953919550400227662034348600306344822714622362401806897194638772970868697130737377734802547862929588";

void QuadraticCongruence(BigNumber a)
{
	int i, j;
	char* waste;
	BigNumber b, s, a_1, x[20] = {}, ans;
	BigNumber tmp, II, prime_1, t1, t2, t3, t4;
	s.data = (char*)malloc(120);
	memset(s.data, '0', 120);
	memcpy(s.data, S, 99);
	s.len = 99;
	b.data = (char*)malloc(120);
	memset(b.data, '0', 102);
	memcpy(b.data, B, 102);
	b.len = 102;
	tmp.data = (char*)malloc(120);
	memset(tmp.data, '0', 120);
	memcpy(tmp.data, PrimeData, 103);
	tmp.len = 103;
	tmp.data[0] = '7';
	prime_1.data = (char*)malloc(120);
	memset(prime_1.data, '0', 120);
	memcpy(prime_1.data, PrimeData, 103);
	prime_1.data[0] = '8';
	prime_1.len = 103;
	ans.data = (char*)malloc(120);
	memset(ans.data, '0', 120);
	memcpy(ans.data, AnsData, 103);
	ans.len = 102;

	a_1 = HyperPow(a, tmp);
	//printf("a_1: %s\n", a_1.data);

	II.data = (char*)malloc(10);
	memset(II.data, '0', 10);
	II.len = 1;

	x[9] = HyperPow(a, s);
	for (i = 8; i >= 0; i--)
	{
		//printf("%d\n", i);
		//printf("%s\n", x[i + 1].data);
		II.data[0] = i + '0';
		waste = t1.data;
		t1 = HyperPow(two, II);
		free(waste);
		waste = t2.data;
		t2 = HyperMul(x[i + 1], x[i + 1]);
		free(waste);
		HyperDiv(t2, prime);
		memcpy(t2.data, mod.data, mod.len);
		t2.len = mod.len;
		waste = t3.data;
		t3 = HyperMul(a_1, t2);
		free(waste);
		HyperDiv(t3, prime);
		memcpy(t3.data, mod.data, mod.len);
		t3.len = mod.len;
		waste = tmp.data;
		tmp = HyperPow(t3, t1);
		free(waste);
		//tmp = HyperPow(HyperMul(a_1, HyperMul(x[i + 1], x[i + 1])), HyperPow(two, II));
		if (HyperCompare(tmp, one) == 0)
		{
			x[i] = x[i + 1];
		}
		else if (HyperCompare(tmp, prime_1) == 0)
		{
			II.data[0] = (8 - i) + '0';
			x[i] = HyperMul(x[i + 1], HyperPow(b, HyperPow(two, II)));
			HyperDiv(x[i], prime);
			memset(x[i].data, '0', 120);
			memcpy(x[i].data, mod.data, mod.len);
			x[i].len = mod.len;
		}
		else
		{
			puts("That's awful. You are not allowed to touch my piano anymore!");
			exit(0);
		}
	}
	//printf("%s", x[0].data);
	for (i = 0; i < ans.len; i++)
	{
		if (x[0].data[i] != ans.data[i])
		{
			puts("That's awful. You are not allowed to touch my piano anymore!");
			exit(0);
		}
	}
	puts("Great one. I will show you the power of moon!");
	puts("By the way, your flag is DubheCTF{md5_32_lower(input)}");
	return;
}

int main()
{
	char flag[50] = "";
	BigNumber str;
	int i;
	
	prime.data = (char*)malloc(120);
	memset(prime.data, '0', 120);
	memcpy(prime.data, PrimeData, 103);
	prime.len = 103;
	mod.data = (char*)malloc(120);
	memset(mod.data, '0', 120);
	zero.data = (char*)malloc(10);
	memset(zero.data, '0', 10);
	zero.len = 1;
	one.data = (char*)malloc(10);
	memset(one.data, '0', 10);
	one.data[0] = '1';
	one.len = 1;
	two.data = (char*)malloc(10);
	memset(two.data, '0', 10);
	two.data[0] = '2';
	two.len = 1;

	str.data = (char*)malloc(120);
	memset(str.data, '0', 120);
	str.len = 100;
	puts("                                                 WW                                  ");
	puts("                                         W   W  W    WWWW                            ");
	puts("                                     WWWWW    WW W WWWWW                             ");
	puts("                                   WWWWWWWWWW  WWWWWWWWWW                            ");
	puts("                                   WWWWWWWWWW  WWWWWWWWW                             ");
	puts("                                  WWWWWWWWWWWWWW WWWW                                ");
	puts("                                 WWWWWWWWWWWWWWWWWWWWWW                              ");
	puts("                               W%WWWWWWWWWWWWWWWW    WW                              ");
	puts("                            W%W%WWWWWWWWWWWWWWWWW W WWW                              ");
	puts("                         %WWWW%]l%WWWWWWWWWWW%WW%%WW                                 ");
	puts("                        %WWWWW%  %WWWWWWWW%W%%W%WW%WWWW                              ");
	puts("                       WWWWWWWWWWWWWWWWW%%W%WWWWWWW%WWWWW                            ");
	puts("                       %WWWWW%WWWWWWWW%%%%%WWWWWWWWWWW%WWWW                          ");
	puts("                      %WWWWW        W%%%%%%%WWW%%%WWWWWWWWW%                         ");
	puts("                     WWWW          W%%%%%%%%WWW%%%%W%WWWWWWWW                        ");
	puts("                     %W          %%%%%%%%%WWWWW%%%%%%WWWWWWWW                        ");
	puts("                                  %WW%%%WWWWWWWW%%%%%%WWWWWWWW                       ");
	puts("            WW                   %WWWW%%W%%WW%%WWWW%%WWWWWWWWWW                      ");
	puts("          WWWWW%W              W%WWWWWWWW%W%WWWWWWW%%WWWWWWWWWW%                     ");
	puts("         WW WWWWW%W           %WWWWWWWW%%WWWWWWWWWWW%WWWWWWWWWWW%  *                 ");
	puts("        WW  WWWWWWW%        W%WWWWWWWW%%%W%WWWWWWWWW%WWWWWWWWWWWW%                   ");
	puts("            WWW% W%W%      WWWWWWWWWWW%WWWW%WWWWWWWWW%WWWWWWWWWWWW%                  ");
	puts("            %WW   WWW%    %WWWWWWWWW%%WWWWWWWWWWWWW%WWWWWWWWWWWWWWWW                 ");
	puts("            %%W    %WWWWW%WWWWWWWW%%%WWWWWWWWWWWWWW%WWWWWWWWWWWWWWWWWW               ");
	puts("           %WW%     WWWWWWWWWWWW%W%%WWWWWWWWWWWWWWW%WWWWWWWWWWWWWWW WW               ");
	puts("            %%      %W%WWWWWWW%%%W%%WWWWWWWWWWWWWW%WWWWWWWWWWWWWWWW   %W             ");
	puts("            %%     %WW%%%%W%%%%%%%%WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW   W             ");
	puts("            %%   %%%%%%%%%%%%%%W%%WWWWWWWWWWWWWWWWWWWWWWWWW WWWWWWWW                 ");
	puts("            %%W%%W%%%%%%%%%W%%%%%WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW                ");
	puts("            %%WWWWW%%%%%%%%%%%%%WWWWWWWWWWWWWWWWWWWWWWWWWWWW WWWWWWWWW               ");
	puts("            W%WWWW%%%%%%%%%%%%%%WWWW%%WWWWWWWWWWWWWWWWWWWWWW WWWWWWWWW               ");
	puts("           WWWWWW%%%%WWWW%%%%%%WWWWWW%WWWWWWWWWWWWWWWWWWWWWWW WWWWWWWWWW            W");
	puts("          WWWW%%WW      WW%%%%WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW WWWWWWWWWW         WW W");
	puts("         %WWWW         W%%%%%WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW WWWWWWWWW        W WWW");
	puts("        WWW W%      W W%%%%%WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW   WWWWWWWWW    WW  WWWW");
	puts("            WW     W WW%%%%WWWWW%WWWWWWWWWWWWWWWW  WWWWW W  WW  WWWWWWWWW    WWWWWWWW");
	puts("            WW    WWWWWWWW%WWWWWWWWWWWWWWWWWWWWWW    WW         WW%WWW W    WWWWWWWWW");
	puts("W           WW   WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW               W        WW WWWWWWWW");
	puts("WWW         WW  WWWWWWWWWW WWWWWWWWWWWWWWWWW WWWWWWW            W          WWWWWWWWWW");
	puts("WWWW        WW WWWWWWW  W  WWWWWWWWWWWWWW        WW                           WWWWWWW");
	puts("WWWW        WWWWWWWWW W  W  W  WWWWWWWWW                                  WWWWWWWWWWW");
	puts("WWW         WW WWWWWWW WW       WWWWW                                      WWWWWWWWWW");
	puts("WWW         W    W WW  W                                                  WWWWWWWWWW%");
	puts("%%%WWWW                                                                WWWWWWW%W%%%%%");
	puts("What kind of music can you play?");
	for (i = 0; i < 100; i++)
	{
		flag[i] = getchar();
		if (flag[i] == '\n')
			break;
		if (!(flag[i] >= '0' && flag[i] <= '9') && !(flag[i] >= 'A' && flag[i] <= 'F'))
		{
			puts("That's awful. You are not allowed to touch my piano anymore!");
			return 0;
		}
		str.data[100 - i - 1] = flag[i];
	}

	QuadraticCongruence(str);

	return 0;
}