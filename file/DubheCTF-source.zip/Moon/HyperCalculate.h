int HyperCompare(BigNumber a, BigNumber b)
{
	int i;
	if (a.len > b.len) return 1;
	if (a.len < b.len) return -1;
	for (i = a.len - 1; i >= 0; i--)
	{
		if (a.data[i] > b.data[i]) return 1;
		if (a.data[i] < b.data[i]) return -1;
	}
	return 0;
}

BigNumber HyperAdd(BigNumber a, BigNumber b)
{
	int i;
	int maxLen, sum, c = 0;
	BigNumber res;
	res.data = (char*)malloc(120);
	memset(res.data, '0', 120);
	maxLen = a.len > b.len ? a.len : b.len;

	for (i = 0; i < maxLen; i++)
	{
		sum = (a.data[i] - '0') + (b.data[i] - '0') + c;
		res.data[i] = sum % 10 + '0';
		c = sum / 10;
	}
	if (c == 0)
	{
		res.len = maxLen;
		return res;
	}
	else
	{
		res.data[maxLen] = '1';
		res.len = maxLen + 1;
		return res;
	}
}

BigNumber HyperSub(BigNumber a, BigNumber b)
{
	int i;
	int sub, c = 0;
	BigNumber res;
	res.data = (char*)malloc(120);
	memset(res.data, '0', 120);

	for (i = 0; i < a.len; i++)
	{
		sub = (a.data[i] - '0') - (b.data[i] - '0') - c;
		if (sub < 0)
		{
			c = 1;
			sub += 10;
		}
		else
		{
			c = 0;
		}
		res.data[i] = sub + '0';
	}
	//printf("a   %d %s\n", a.len, a.data);
	//printf("b   %d %s\n", b.len, b.data);
	//printf("div %d %s\n", res.len, res.data);
	res.len = a.len;
	for (i = a.len - 1; i > 0; i--)
	{
		if (res.data[i] == '0')
		{
			res.len--;
		}
		else
		{
			break;
		}
	}
	//printf("%d\n\n", res.len);
	return res;
}

BigNumber HyperMul(BigNumber a, BigNumber b)
{
	int i, j, k;
	int sum, c;
	BigNumber res;
	res.data = (char*)malloc(220);
	memset(res.data, '0', 220);
	BigNumber tmp;
	tmp.data = (char*)malloc(120);
	memset(tmp.data, '0', 120);

	for (i = 0; i < b.len; i++)
	{
		c = 0;
		memset(tmp.data, '0', 120);
		for (j = 0; j < a.len; j++)
		{
			sum = (a.data[j] - '0') * (b.data[i] - '0') + c;
			tmp.data[j] = sum % 10 + '0';
			c = sum / 10;
		}
		if (c == 0)
		{
			tmp.len = a.len;
		}
		else
		{
			tmp.data[a.len] = c + '0';
			tmp.len = a.len + 1;
		}
		//printf("%d %s\n", tmp.len, tmp.data);

		c = 0;
		for (j = i; j < i + tmp.len; j++)
		{
			sum = (res.data[j] - '0') + (tmp.data[j - i] - '0') + c;
			res.data[j] = sum % 10 + '0';
			c = sum / 10;
		}
		if (c != 0)
		{
			res.data[i + tmp.len] = '1';
		}
	}
	if (b.len == 1 && b.data[0] == '0')
	{
		res.len = 1;
		free(tmp.data);
		return res;
	}
	if (res.data[a.len + b.len - 1] == '0')
	{
		res.len = a.len + b.len - 1;
	}
	else
	{
		res.len = a.len + b.len;
	}
	free(tmp.data);
	return res;
}

BigNumber HyperDiv(BigNumber a, BigNumber b)
{
	int i, j;
	char* waste;
	BigNumber res;
	res.data = (char*)malloc(120);
	memset(res.data, '0', 120);
	BigNumber tmp;
	tmp.data = (char*)malloc(120);
	BigNumber div;
	div.data = (char*)malloc(120);
	memset(div.data, '0', 120);

	if (HyperCompare(a, b) == -1)
	{
		res.len = 1;
		memcpy(mod.data, a.data, 120);
		mod.len = a.len;
		free(tmp.data);
		free(div.data);
		return res;
	}
	for (i = 0; i < b.len; i++)
	{
		div.data[i] = a.data[a.len - b.len + i];
	}
	div.len = b.len;
	//printf("%s\n", div.data);
	for (i = a.len - b.len; i >= 0; i--)
	{
		//printf("div %s\n", div.data);
		for (j = 1; j < 10; j++)
		{
			memset(tmp.data, '0', 120);
			tmp.data[0] = j + '0';
			tmp.len = 1;
			//printf("%s\n", tmp.data);
			waste = tmp.data;
			tmp = HyperMul(b, tmp);
			free(waste);
			//printf("%s\n\n", tmp.data);
			//printf("%s\n\n", div.data);
			
			if (HyperCompare(tmp, div) == 1)
			{
				break;
			}
		}
		res.data[i] = j - 1 + '0';
		memset(tmp.data, '0', 120);
		tmp.data[0] = j - 1 + '0';
		tmp.len = 1;
		waste = tmp.data;
		tmp = HyperMul(b, tmp);
		free(waste);
		//printf("tmp %s\n", tmp.data);
		//printf("div %s\n", div.data);
		waste = div.data;
		div = HyperSub(div, tmp);
		free(waste);
		for (j = div.len - 1; j > 0; j--)
		{
			if (div.data[j] == '0')
			{
				div.len--;
			}
			else
			{
				break;
			}
		}
		//printf("div %s\n\n", div.data);
		if (i == 0)
		{
			break;
		}
		if (div.len == 1 && div.data[0] == '0')
		{
			div.len--;
		}
		for (j = div.len; j >= 1; j--)
		{
			div.data[j] = div.data[j - 1];
		}
		div.data[0] = a.data[i - 1];
		div.len += 1;
	}
	memset(mod.data, '0', 120);
	memcpy(mod.data, div.data, 120);
	mod.len = div.len;
	if (res.data[a.len - b.len] == '0')
	{
		res.len = a.len - b.len;
	}
	else
	{
		res.len = a.len - b.len + 1;
	}
	free(tmp.data);
	free(div.data);
	return res;
}

BigNumber HyperPow(BigNumber a, BigNumber b)
{
	int i;
	char* waste;
	BigNumber res;
	res.data = (char*)malloc(120);
	res.len = 1;
	memset(res.data, '0', 120);
	res.data[0] = '1';
	BigNumber tmp1;
	tmp1.data = (char*)malloc(120);
	tmp1.len = a.len;
	memset(tmp1.data, '0', 120);
	memcpy(tmp1.data, a.data, a.len);
	BigNumber tmp2;
	tmp2.data = (char*)malloc(120);
	tmp2.len = b.len;
	memset(tmp2.data, '0', 120);
	memcpy(tmp2.data, b.data, b.len);

	while (HyperCompare(tmp2, zero) == 1)
	{
		if ((tmp2.data[0] - '0') % 2 == 1)
		{
			//printf("res %s\na %s\n", res.data, a.data);
			waste = res.data;
			res = HyperMul(res, tmp1);
			free(waste);
			//printf("res %s\n", res.data);
			HyperDiv(res, prime);
			memcpy(res.data, mod.data, 120);
			res.len = mod.len;
		}
		//printf("%s\n", a.data);
		waste = tmp1.data;
		tmp1 = HyperMul(tmp1, tmp1);
		free(waste);
		//printf("%s\n", a.data);
		HyperDiv(tmp1, prime);
		memset(tmp1.data, '0', 120);
		memcpy(tmp1.data, mod.data, 120);
		tmp1.len = mod.len;
		//printf("%d %s\n\n", a.len, a.data);
		waste = tmp2.data;
		tmp2 = HyperDiv(tmp2, two);
		free(waste);
		//printf("%s\n\n", b.data);
	}
	free(tmp1.data);
	free(tmp2.data);
	return res;
}