code = [
'L000:',
'    push   ebp',
'    jmp    L001',
'L11b:',
'    shl    esi,0x4',
'    jmp    L11e',
'L03b:',
'    mov    edx,DWORD PTR [ecx+flag]',
'    jmp    L041',
'L047:',
'    sub    eax,0x5b4b9f9e',
'    jmp    L04c',
'L058:',
'    mov    DWORD PTR [ebp-0x20],eax',
'    jmp    L05b',
'L06a:',
'    mov    DWORD PTR [ebp-0x14],eax',
'    jmp    L06d',
'L076:',
'    mov    ecx,DWORD PTR [eax*4+flag+4]',
'    jmp    L07d',
'L155:',
'    mov    ecx,DWORD PTR [ebp-0x10c]',
'    jmp    L15b',
'L009:',
'    push   ebx',
'    jmp    L00a',
'L15b:',
'    mov    DWORD PTR [eax+flag],ecx',
'    jmp    L161',
'L16d:',
'    sub    eax,0x1',
'    jmp    L170',
'L173:',
'    jne    L044',
'    jmp    L179',
'L191:',
'    ret',
'    jmp    LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL',
'L04f:',
'    mov    eax,DWORD PTR [ebp-0x44]',
'    jmp    L052',
'L122:',
'    mov    eax,DWORD PTR [ebp-0x44]',
'    jmp    L125',
'L09e:',
'    mov    edx,DWORD PTR [ebp-0x44]',
'    jmp    L0a1',
'L152:',
'    imul   eax,edx,0xb',
'    jmp    L155',
'L052:',
'    shr    eax,0x2',
'    jmp    L055',
'L0d0:',
'    mov    eax,DWORD PTR [ebp-0x10c]',
'    jmp    L0d6',
'L112:',
'    mov    eax,DWORD PTR [ebp-0x2c]',
'    jmp    L115',
'L094:',
'    mov    ecx,DWORD PTR [ebp-0x38]',
'    jmp    L097',
'L0e3:',
'    mov    DWORD PTR [ebp-0x38],ecx',
'    jmp    L0e6',
'L120:',
'    add    edx,eax',
'    jmp    L122',
'L128:',
'    mov    esi,DWORD PTR [ebp-0x14]',
'    jmp    L12b',
'L07d:',
'    mov    DWORD PTR [ebp-0x2c],ecx',
'    jmp    L080',
'L0c5:',
'    add    ecx,eax',
'    jmp    L0c7',
'L161:',
'    mov    edx,DWORD PTR [ebp-0x10c]',
'    jmp    L167',
'L08e:',
'    mov    edx,DWORD PTR [ebp-0x2c]',
'    jmp    L091',
'L001:',
'    mov    ebp,esp',
'    jmp    L003',
'L115:',
'    shr    eax,0x3',
'    jmp    L118',
'L16a:',
'    mov    eax,DWORD PTR [ebp-0x8]',
'    jmp    L16d',
'L179:',
'    mov    eax,0x1',
'    jmp    L17e',
'L17e:',
'    pop    edi',
'    jmp    L17f',
'L0b7:',
'    add    edx,ecx',
'    jmp    L0b9',
'L12b:',
'    and    esi,0x3',
'    jmp    L12e',
'L09a:',
'    xor    edx,ecx',
'    jmp    L09c',
'L00b:',
'    push   edi',
'    jmp    L025',
'L071:',
'    jae    L0eb',
'    jmp    L073',
'L0b4:',
'    xor    ecx,DWORD PTR [ebp-0x38]',
'    jmp    L0b7',
'L10a:',
'    mov    eax,DWORD PTR [ebp-0x2c]',
'    jmp    L10d',
'L073:',
'    mov    eax,DWORD PTR [ebp-0x14]',
'    jmp    L076',
'L038:',
'    imul   ecx,eax,0xb',
'    jmp    L03b',
'L0a1:',
'    xor    edx,DWORD PTR [ebp-0x2c]',
'    jmp    L0a4',
'L0a4:',
'    mov    ecx,DWORD PTR [ebp-0x14]',
'    jmp    L0a7',
'L04c:',
'    mov    DWORD PTR [ebp-0x44],eax',
'    jmp    L04f',
'L104:',
'    mov    edx,DWORD PTR [ebp-0x38]',
'    jmp    L107',
'L10d:',
'    shl    eax,0x2',
'    jmp    L110',
'L118:',
'    mov    esi,DWORD PTR [ebp-0x38]',
'    jmp    L11b',
'L13f:',
'    mov    ecx,DWORD PTR [ecx+flag]',
'    jmp    L145',
'L025:',
'    mov    DWORD PTR [ebp-0x8],0x32',
'    jmp    L02c',
'L0dd:',
'    mov    ecx,DWORD PTR [ebp-0x10c]',
'    jmp    L0e3',
'L033:',
'    mov    eax,0x4',
'    jmp    L038',
'L145:',
'    add    ecx,edx',
'    jmp    L147',
'L044:',
'    mov    eax,DWORD PTR [ebp-0x44]',
'    jmp    L047',
'L17f:',
'    pop    esi',
'    jmp    L180',
'L0a7:',
'    and    ecx,0x3',
'    jmp    L0aa',
'L062:',
'    jmp    L06d',
'    jmp    L064',
'L0ad:',
'    mov    ecx,DWORD PTR [ecx*4+key]',
'    jmp    L0b4',
'L0d6:',
'    mov    DWORD PTR [edx*4+flag],eax',
'    jmp    L0dd',
'L0e6:',
'    jmp    L064',
'    jmp    L0eb',
'L080:',
'    mov    eax,DWORD PTR [ebp-0x38]',
'    jmp    L083',
'L138:',
'    xor    esi,DWORD PTR [ebp-0x38]',
'    jmp    L13b',
'L107:',
'    shr    edx,0x5',
'    jmp    L10a',
'L13d:',
'    xor    edx,eax',
'    jmp    L13f',
'L11e:',
'    xor    eax,esi',
'    jmp    L120',
'L041:',
'    mov    DWORD PTR [ebp-0x38],edx',
'    jmp    L044',
'L0aa:',
'    xor    ecx,DWORD PTR [ebp-0x20]',
'    jmp    L0ad',
'L0be:',
'    mov    ecx,DWORD PTR [edx*4+flag]',
'    jmp    L0c5',
'L0f9:',
'    mov    DWORD PTR [ebp-0x2c],edx',
'    jmp    L0fc',
'L064:',
'    mov    eax,DWORD PTR [ebp-0x14]',
'    jmp    L067',
'L0cd:',
'    mov    edx,DWORD PTR [ebp-0x14]',
'    jmp    L0d0',
'L00a:',
'    push   esi',
'    jmp    L00b',
'L131:',
'    mov    esi,DWORD PTR [esi*4+key]',
'    jmp    L138',
'L167:',
'    mov    DWORD PTR [ebp-0x38],edx',
'    jmp    L16a',
'L170:',
'    mov    DWORD PTR [ebp-0x8],eax',
'    jmp    L173',
'L180:',
'    pop    ebx',
'    jmp    L181',
'L181:',
'    add    esp,0x10c',
'    jmp    L18e',
'L12e:',
'    xor    esi,DWORD PTR [ebp-0x20]',
'    jmp    L131',
'L18e:',
'    mov    esp,ebp',
'    jmp    L190',
'L09c:',
'    add    eax,edx',
'    jmp    L09e',
'L190:',
'    pop    ebp',
'    jmp    L191',
'L05b:',
'    mov    DWORD PTR [ebp-0x14],0x0',
'    jmp    L062',
'L06d:',
'    cmp    DWORD PTR [ebp-0x14],0xb',
'    jmp    L071',
'L097:',
'    shl    ecx,0x4',
'    jmp    L09a',
'L091:',
'    shr    edx,0x3',
'    jmp    L094',
'L147:',
'    mov    DWORD PTR [ebp-0x10c],ecx',
'    jmp    L14d',
'L0c7:',
'    mov    DWORD PTR [ebp-0x10c],ecx',
'    jmp    L0cd',
'L089:',
'    shl    ecx,0x2',
'    jmp    L08c',
'L055:',
'    and    eax,0x3',
'    jmp    L058',
'L0f0:',
'    imul   ecx,eax,0x0',
'    jmp    L0f3',
'L0fc:',
'    mov    eax,0x4',
'    jmp    L101',
'L02c:',
'    mov    DWORD PTR [ebp-0x44],0x0',
'    jmp    L033',
'L083:',
'    shr    eax,0x5',
'    jmp    L086',
'L086:',
'    mov    ecx,DWORD PTR [ebp-0x2c]',
'    jmp    L089',
'L0eb:',
'    mov    eax,0x4',
'    jmp    L0f0',
'L003:',
'    sub    esp,0x10c',
'    jmp    L009',
'L110:',
'    xor    edx,eax',
'    jmp    L112',
'L14d:',
'    mov    edx,0x4',
'    jmp    L152',
'L125:',
'    xor    eax,DWORD PTR [ebp-0x2c]',
'    jmp    L128',
'L067:',
'    add    eax,0x1',
'    jmp    L06a',
'L13b:',
'    add    eax,esi',
'    jmp    L13d',
'L0b9:',
'    xor    eax,edx',
'    jmp    L0bb',
'L101:',
'    imul   ecx,eax,0xb',
'    jmp    L104',
'L08c:',
'    xor    eax,ecx',
'    jmp    L08e',
'L0bb:',
'    mov    edx,DWORD PTR [ebp-0x14]',
'    jmp    L0be',
'L0f3:',
'    mov    edx,DWORD PTR [ecx+flag]',
'    jmp    L0f9'
]

'''
fucked = ['' for _ in range(len(code))]

from random import *
for c in code:
    r = randint(0, len(code) - 1)
    while fucked[r] != '':
        r = (r + 1) % len(code)
    fucked[r] = c

for f in fucked:
    print('\''+f+'\'', end = ',\n')
'''

pre_order = [0x000, 0x001, 0x003, 0x009, 0x00a, 0x00b, 0x025, 0x02c, 0x033, 0x038, 0x03b, 0x041, 0x044, 0x047, 0x04c, 0x04f, 0x052, 0x055, 0x058, 0x05b, 0x062, 0x064, 0x067, 0x06a, 0x06d, 0x071, 0x073, 0x076, 0x07d, 0x080, 0x083, 0x086, 0x089, 0x08c, 0x08e, 0x091, 0x094, 0x097, 0x09a, 0x09c, 0x09e, 0x0a1, 0x0a4, 0x0a7, 0x0aa, 0x0ad, 0x0b4, 0x0b7, 0x0b9, 0x0bb, 0x0be, 0x0c5, 0x0c7, 0x0cd, 0x0d0, 0x0d6, 0x0dd, 0x0e3, 0x0e6, 0x0eb, 0x0f0, 0x0f3, 0x0f9, 0x0fc, 0x101, 0x104, 0x107, 0x10a, 0x10d, 0x110, 0x112, 0x115, 0x118, 0x11b, 0x11e, 0x120, 0x122, 0x125, 0x128, 0x12b, 0x12e, 0x131, 0x138, 0x13b, 0x13d, 0x13f, 0x145, 0x147, 0x14d, 0x152, 0x155, 0x15b, 0x161, 0x167, 0x16a, 0x16d, 0x170, 0x173, 0x179, 0x17e, 0x17f, 0x180, 0x181, 0x18e, 0x190, 0x191]
cur_order = [0x000, 0x11b, 0x03b, 0x047, 0x058, 0x06a, 0x076, 0x155, 0x009, 0x15b, 0x16d, 0x173, 0x191, 0x04f, 0x122, 0x09e, 0x152, 0x052, 0x0d0, 0x112, 0x094, 0x0e3, 0x120, 0x128, 0x07d, 0x0c5, 0x161, 0x08e, 0x001, 0x115, 0x16a, 0x179, 0x17e, 0x0b7, 0x12b, 0x09a, 0x00b, 0x071, 0x0b4, 0x10a, 0x073, 0x038, 0x0a1, 0x0a4, 0x04c, 0x104, 0x10d, 0x118, 0x13f, 0x025, 0x0dd, 0x033, 0x145, 0x044, 0x17f, 0x0a7, 0x062, 0x0ad, 0x0d6, 0x0e6, 0x080, 0x138, 0x107, 0x13d, 0x11e, 0x041, 0x0aa, 0x0be, 0x0f9, 0x064, 0x0cd, 0x00a, 0x131, 0x167, 0x170, 0x180, 0x181, 0x12e, 0x18e, 0x09c, 0x190, 0x05b, 0x06d, 0x097, 0x091, 0x147, 0x0c7, 0x089, 0x055, 0x0f0, 0x0fc, 0x02c, 0x083, 0x086, 0x0eb, 0x003, 0x110, 0x14d, 0x125, 0x067, 0x13b, 0x0b9, 0x101, 0x08c, 0x0bb, 0x0f3]

'''
for c in code:
    print('\'' + c[:5] + '\',')
    print('\'    ' + c[6:] + '\',')
'''
    
'''
for i in range(0, len(code), 2):
    Label = int(code[i][1] + code[i][2] + code[i][3], 16)
    print('\'' + code[i] + '\',')
    print('\'' + code[i+1] + '\',')
    next_Label = -1
    for j in range(len(pre_order)):
        if pre_order[j] == Label:
            if j != len(pre_order) - 1:
                next_Label = pre_order[j + 1]
            break

    if next_Label == -1:
        next_Label = 'LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL'
    else:
        next_Label = hex(next_Label)[2:]

    if len(next_Label) == 1:
        next_Label = 'L00' + next_Label
    elif len(next_Label) == 2:
        next_Label = 'L0' + next_Label
    else:
        next_Label = 'L' + next_Label
    
    print('\'    jmp    ' + next_Label + '\',')
'''

'''
from random import *

nJJ = 0
nCC = 0
f = open('fuckcode.txt', 'w')
for i in range(0, len(code), 3):
    f.write(code[i] + '\n')
    f.write(code[i+1] + '\n')
    if randint(0, 1) == 0 and not('L06d' in code[i]) and not('L16d' in code[i]) and not('L170' in code[i]):
        nCC += 1
        f.write('    call    $+5\n')
        f.write('    add     DWORD PTR [esp], 5\n')
        f.write('    ret\n')
    if randint(0, 1) == 0:
        f.write(code[i+2] + '\n')
    else:
        nJJ += 1
        f.write('    jz    ' + code[i+2][11:] + '\n')
        f.write('    jnz   ' + code[i+2][11:] + '\n')
    times = randint(50, 100)
    for j in range(times):
        f.write('    _emit ' + hex(randint(0, 255)) + '\n')
'''

# for Label in pre_order:
#     Label = hex(Label)[2:]
#     if len(Label) == 1:
#         Label = '00' + Label
#     elif len(Label) == 2:
#         Label = '0' + Label
#     for i in range(0, len(code), 3):
#         if Label in code[i]:
#             print(code[i])
#             print(code[i+1])
 
for c in code:
    print(c)