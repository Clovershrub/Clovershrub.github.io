#include <stdlib.h>
#include <stdio.h>

char* Page[60] = {};
char defence[100];

void menu()
{
    puts("1.Create a page.");
    puts("2.Delete a page.");
    puts("3.Browse a page.");
    puts("Your choice:");
}

void Create()
{
    int i, size;
    puts("How long are you going to write?");
    scanf("%d", &size);
    if(!(size >= 0 && size <= 0x100))
    {
        puts("No way!");
        return;
    }
    for(i = 0; i < 50; i++)
    {
        if(!Page[i])
        {
            Page[i] = malloc(size);
            puts("Now, begin.");
            read(0, Page[i], size);
            Page[i][size-1] = 0;
            break;
        }
    }
    puts("You can't protect anything!");
}

void Delete()
{
    int id;
    puts("Which one do you want to delete?");
    scanf("%d", &id);
    if(!(id >= 0 && id < 50))
    {
        puts("No way!");
        return;
    }
    if(!Page[id])
    {
        puts("No way!");
        return;
    }
    free(Page[id]);
    puts("You can't protect anything!");
}

void Browse()
{
    int id;
    puts("Which one do you want to see?");
    scanf("%d", &id);
    if(!(id >= 0 && id < 50))
    {
        puts("No way!");
        return;
    }
    if(!Page[id])
    {
        puts("No way!");
        return;
    }
    puts(Page[id]);
    puts("You can't protect anything!");
}

void Record()
{
    puts("Tell me what you have done before.");
    int choice;
    while(1)
    {
        menu();
        scanf("%d", &choice);
        switch(choice)
        {
            case 1:
                Create();
                break;
            case 2:
                Delete();
                break;
            case 3:
                Browse();
                break;
            default:
                puts("emmm...it doesn't seem like...");
                return 0;
        }
    }
}

void Defence()
{
    puts("What defence do you want?");
    read(0, defence, 80);
    printf(defence);
    puts("Child, what makes you think this is possible?");
}

void Weapon()
{
    char name[100] = {};
    puts("What weapon do you want?");
    read(0, name, 0x100);
    puts("Impossible.");
}

int main()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);

    puts("I have heard the call of \"PoWanFa\", is that yours?");
    puts("What would you like to do?");
    puts("1.Buy some weapons.");
    puts("2.Buy some defences.");
    puts("3.Record.");
    puts("Your choice:");
    int choice;
    scanf("%d", &choice);
    switch(choice)
    {
        case 1:
            Weapon();
            break;
        case 2:
            Defence();
            break;
        case 3:
            Record();
            break;
        default:
            puts("emmm...it doesn't seem like...");
    }
    return 0;
}