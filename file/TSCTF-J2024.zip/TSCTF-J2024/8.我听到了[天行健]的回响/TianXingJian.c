#include <stdlib.h>
#include <stdio.h>
#include <seccomp.h>

char* List[200] = {};

void init()
{
    scmp_filter_ctx ctx;
    ctx = seccomp_init(SCMP_ACT_KILL);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit), 0);
    seccomp_load(ctx);
    return;
}

void menu()
{
    puts("Describe how strong you are!");
    puts("1.Create a description.");
    puts("2.Delete a description.");
    puts("3.Browse a description.");
    puts("Your choice:");
}

void Create()
{
    int size, i;
    puts("How long are you going to write?");
    scanf("%d", &size);
    for(i = 0; i < 150; i++)
    {
        if(!List[i])
        {
            List[i] = malloc(size);
            break;
        }
    }
    if(i >= 150)
    {
        puts("FULL!");
        return;
    }
    puts("Now, begin.");
    List[i][read(0, List[i], size)] = 0;
    puts("I don't think you will win with this weak body!");
}

void Delete()
{
    int id;
    puts("Which one do you want to delete?");
    scanf("%d", &id);
    if(!(id >= 0 && id < 150))
    {
        puts("No way!");
        return;
    }
    if(!List[id])
    {
        puts("No way!");
        return;
    }
    free(List[id]);
    List[id] = 0;
    puts("I don't think you will win with this weak body!");
}

void Browse()
{
    int id;
    puts("Which one do you want to see?");
    scanf("%d", &id);
    if(!(id >= 0 && id < 150))
    {
        puts("No way!");
        return;
    }
    if(!List[id])
    {
        puts("No way!");
        return;
    }
    puts(List[id]);
    puts("I don't think you will win with this weak body!");
}

int main()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    init();

    puts("I have heard the call of \"TianXingJian\", is that yours?");
    puts("Oh...such weak body...you will definitely lose...");
    int choice;
    while(1)
    {
        menu();
        scanf("%d", &choice);
        switch(choice)
        {
            case 1:
                Create();
                break;
            case 2:
                Delete();
                break;
            case 3:
                Browse();
                break;
            default:
                puts("emmm...it doesn't seem like...");
                return 0;
        }
    }
    return 0;
}