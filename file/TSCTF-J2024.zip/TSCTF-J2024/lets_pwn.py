from os import system

docker_file_template = '''
FROM %s

RUN sed -i "s/http:\/\/archive.ubuntu.com/http:\/\/mirrors.tuna.tsinghua.edu.cn/g" /etc/apt/sources.list
RUN apt update && apt -y dist-upgrade
RUN apt install -y lib32z1 xinetd

RUN useradd -m ctf

WORKDIR /home/ctf

%sRUN cp -R /lib* /home/ctf
RUN cp -R /usr/lib* /home/ctf

RUN mkdir /home/ctf/dev && \\
    mknod /home/ctf/dev/null c 1 3 && \\
    mknod /home/ctf/dev/zero c 1 5 && \\
    mknod /home/ctf/dev/random c 1 8 && \\
    mknod /home/ctf/dev/urandom c 1 9 && \\
    chmod 666 /home/ctf/dev/*

RUN mkdir /home/ctf/bin && \\
    cp /bin/sh /home/ctf/bin && \\
    cp /bin/ls /home/ctf/bin && \\
    cp /bin/cat /home/ctf/bin

COPY ./ctf.xinetd /etc/xinetd.d/ctf
COPY ./start.sh /start.sh
RUN echo "Blocked by ctf_xinetd" > /etc/banner_fail

RUN chmod +x /start.sh

COPY ./bin/ /home/ctf/
RUN chown -R root:ctf /home/ctf && \\
    chmod -R 750 /home/ctf && \\
    chmod 740 /home/ctf/flag

CMD ["/start.sh"]

EXPOSE 9999
'''

ctf_xinetd_template = '''
service ctf
{
    disable = no
    socket_type = stream
    protocol    = tcp
    wait        = no
    user        = root
    type        = UNLISTED
    port        = 9999
    bind        = 0.0.0.0
    server      = /usr/sbin/chroot
    # replace helloworld to your program
    server_args = --userspec=%s:%s /home/ctf ./%s
    banner_fail = /etc/banner_fail
    # safety options
    per_source	= %s # the maximum instances of this service per source IP address
    rlimit_cpu	= 20 # the maximum number of CPU seconds that the service may use
    %s
    # rlimit_as  = 1024M # the Address Space resource limit for the service
    # access_times = 2:00-9:00 12:00-24:00
}
'''

flag_template = 'ctf{It is you are the caller of "%s"}'

config_file = open('TSCTF-J2024/configuration', 'r')

system('mkdir build')
system('mkdir build/bin')
system('cp /home/kali/Desktop/ctf_xinetd/start.sh ./build')
while(1):
    config = config_file.readline().replace('\n', '').split(' ')
    print(config)
    if config == ['']:
        break
    # if config[0] != 'ShengShengBuXi':
    #     continue

    docker_file_file = open('build/Dockerfile', 'w')
    ctf_xinetd_file = open('build/ctf.xinetd', 'w')
    flag_file = open('build/bin/flag', 'w')

    flag = flag_template%(config[0])
    note = ''
    if config[3] == '1':
        note = '# '
    docker_file = docker_file_template%(config[1], note)
    if config[6] == '1':
        ctf_xinetd = ctf_xinetd_template%(config[4], config[4], config[0], config[5], "timeout = 60")
    else:
        ctf_xinetd = ctf_xinetd_template%(config[4], config[4], config[0], config[5], "")
    docker_file_file.write(docker_file)
    ctf_xinetd_file.write(ctf_xinetd)
    flag_file.write(flag)
    docker_file_file.close()
    ctf_xinetd_file.close()
    flag_file.close()

    system(f'cp TSCTF-J2024/bin/{config[0]} build/bin')
    system('chown -R kali:kali build')
    system(f'docker build -t "{config[0].lower()}" ./build/')
    # system(f'docker run -d -p "{config[2]}:9999" -h "{config[0]}" --name="{config[0]}" {config[0].lower()}')
    system(f'rm build/Dockerfile build/ctf.xinetd build/bin/flag build/bin/{config[0]}')

system('rm -rf build')