#include <stdlib.h>
#include <stdio.h>
#include <seccomp.h>
#include <unistd.h>
#include <sys/mman.h>


char* record[5];
char code[200] = "";

void init()
{
    scmp_filter_ctx ctx;
    ctx = seccomp_init(SCMP_ACT_KILL);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 2, SCMP_A1(SCMP_CMP_EQ, 0x95270000), SCMP_A2(SCMP_CMP_LE, 50));
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 0);
    seccomp_load(ctx);
    return;
}

void my_puts(char* s)
{
    int i;
    for(i = 0; s[i]; i++)
    {
        write(1, &s[i], 1);
    }
    write(1, "\n", 1);
}

int main()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);

    int track, i;
    my_puts("I have heard the call of \"TanNang\", is that yours?");
    for(i = 0; i < 5; i++)
    {
        record[i] = malloc(0x100);
    }
    my_puts("Whitch track do you like?");
    scanf("%d", &track);
    if(track >= 5)
    {
        my_puts("No Way!");
        exit(0);
    }
    my_puts("More than 40% people chose the same one!");

    my_puts("Try to get the flag file!");
    read(0, code, 21);
    mprotect(0x404000, 50, 7);
    mmap(0x95270000, 0x1000, 3, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
    my_puts("Just leave some suggestions for others!");
    read(0, record[track], 0x80);
    init();
    asm("push %rax;");
    asm("push %rbx;");
    asm("push %rcx;");
    asm("push %rdx;");
    asm("push %rsi;");
    asm("push %rdi;");
    asm("push %r8 ;");
    asm("push %r9 ;");
    asm("push %r10;");
    asm("push %r11;");
    asm("push %r12;");
    asm("push %r13;");
    asm("push %r14;");
    asm("push %r15;");
    asm("movq $0x7f, %rax;");
    asm("movq $0x7f, %rbx;");
    asm("movq $0x7f, %rcx;");
    asm("movq $0x7f, %rdx;");
    asm("movq $0x7f, %rsi;");
    asm("movq $0x7f, %rdi;");
    asm("movq $0x7f, %r8 ;");
    asm("movq $0x7f, %r9 ;");
    asm("movq $0x7f, %r10;");
    asm("movq $0x7f, %r11;");
    asm("movq $0x7f, %r12;");
    asm("movq $0x7f, %r13;");
    asm("movq $0x7f, %r14;");
    asm("movq $0x7f, %r15;");
    (*(void(*)())code)();
    asm("pop %r15;");
    asm("pop %r14;");
    asm("pop %r13;");
    asm("pop %r12;");
    asm("pop %r11;");
    asm("pop %r10;");
    asm("pop %r9 ;");
    asm("pop %r8 ;");
    asm("pop %rdi;");
    asm("pop %rsi;");
    asm("pop %rdx;");
    asm("pop %rcx;");
    asm("pop %rbx;");
    asm("pop %rax;");
    // mprotect(code - 0xC0, 50, 4);
    read(3, 0x95270000, 50);
    
    my_puts("emmm...it doesn't seem like...");
    return 0;
}