#include <stdio.h>
#include <unistd.h>

int pow(int a, int n)
{
    int i, ans = 1;
    for(i = 0; i < n; i++)
    {
        ans *= a;
    }
    return ans;
}

void HighBird()
{
    int i, j, k;
    puts("");
    puts("高鸟即将对你进行审判。");
    puts("有1号和2号两个箱子，你可以向1号箱子里放入5-10颗鹅卵石，高鸟会向2号箱子里放入不少于10颗鹅卵石。");
    puts("两人轮流从箱子中往外摸任意颗石子(至少1颗)，将两个箱子摸至全空的获胜。");
    puts("一人可以优先摸石子，而另一人可以选择让他第一次从哪个箱子里摸石子。");
    puts("总计进行5轮游戏。");
    puts("");
    int box1, box2, choice, tmp;
    for(i = 0; i < 5; i++)
    {
        while(1)
        {
            printf("你想要向1号盒子投入多少颗鹅卵石？");
            scanf("%d", &box1);
            if(!(box1 >= 5 && box1 <= 10))
            {
                puts("数量错误。");
            }
            else
            {
                break;
            }
        }
        read(3, &box2, sizeof(int));
        box2 = box2 > 0 ? box2 : -box2;
        box2 = box2 % 10 + 10;
        printf("高鸟向2号盒子投入%d颗鹅卵石。\n", box2);
        while(1)
        {
            printf("你想要先摸石子(输入1)，还是指定盒子(输入2)？");
            scanf("%d", &choice);
            if(!(choice == 1 || choice == 2))
            {
                puts("选择错误。");
            }
            else
            {
                break;
            }
        }
        if(choice == 1)
        {
            read(3, &tmp, sizeof(int));
            tmp = tmp > 0 ? tmp : -tmp;
            tmp %= 10;
            if(tmp < 7)
            {
                puts("高鸟决定让你先摸1号盒子。");
                while(1)
                {
                    printf("你想从1号盒子中摸多少鹅卵石？");
                    scanf("%d", &tmp);
                    if(!(tmp >= 1 && tmp <= box1))
                    {
                        puts("数量错误。");
                    }
                    else
                    {
                        break;
                    }
                }
                box1 -= tmp;
            }
            else
            {
                puts("高鸟决定让你先摸2号盒子。");
                while(1)
                {
                    printf("你想从2号盒子中摸多少鹅卵石？");
                    scanf("%d", &tmp);
                    if(!(tmp >= 1 && tmp <= box2))
                    {
                        puts("数量错误。");
                    }
                    else
                    {
                        break;
                    }
                }
                box2 -= tmp;
            }
            printf("现在1号盒子还有%d颗鹅卵石，2号盒子还有%d颗鹅卵石。\n", box1, box2);
        }
        else
        {
            while(1)
            {
                printf("你想要高鸟先摸哪个盒子(输入1或2)？");
                scanf("%d", &tmp);
                if(!(tmp == 1 || tmp == 2))
                {
                    puts("选择错误。");
                }
                else
                {
                    break;
                }
            }
        }
        while(1)
        {
            if(choice == 2)
            {
                if(tmp == 1)
                {
                    read(3, &tmp, sizeof(int));
                    tmp = tmp > 0 ? tmp : -tmp;
                    tmp = tmp % box1 + 1;
                    printf("高鸟决定从1号盒子摸%d颗鹅卵石。\n", tmp);
                    box1 -= tmp;
                }
                else
                {
                    printf("高鸟决定从2号盒子摸%d颗鹅卵石。\n", box2 - box1);
                    box2 = box1;
                }
                choice = 1;
            }
            else
            {
                if(box1 > box2)
                {
                    printf("高鸟决定从1号盒子摸%d颗鹅卵石。\n", box1 - box2);
                    box1 = box2;
                }
                else if(box1 < box2)
                {
                    printf("高鸟决定从2号盒子摸%d颗鹅卵石。\n", box2 - box1);
                    box2 = box1;
                }
                else
                {
                    read(3, &tmp, sizeof(int));
                    tmp &= 1;
                    if(tmp == 1)
                    {
                        read(3, &tmp, sizeof(int));
                        tmp = tmp > 0 ? tmp : -tmp;
                        tmp = tmp % box1 + 1;
                        printf("高鸟决定从1号盒子摸%d颗鹅卵石。\n", tmp);
                        box1 -= tmp;
                    }
                    else
                    {
                        read(3, &tmp, sizeof(int));
                        tmp = tmp > 0 ? tmp : -tmp;
                        tmp = tmp % box2 + 1;
                        printf("高鸟决定从2号盒子摸%d颗鹅卵石。\n", tmp);
                        box2 -= tmp;
                    }
                }
            }
            printf("现在1号盒子还有%d颗鹅卵石，2号盒子还有%d颗鹅卵石。\n", box1, box2);
            if(box1 == 0 && box2 == 0)
            {
                puts("高鸟让天平只偏向一边，这样一来无论对谁的审判都能得出结果......");
                exit(0);
            }
            while(1)
            {
                printf("你想要摸哪个盒子(输入1或2)？");
                scanf("%d", &tmp);
                if(!(tmp == 1 || tmp == 2))
                {
                    puts("选择错误。");
                }
                else
                {
                    break;
                }
            }
            if(tmp == 1)
            {
                while(1)
                {
                    printf("你想要从1号盒子摸多少鹅卵石？");
                    scanf("%d", &tmp);
                    if(!(tmp >= 1 && tmp <= box1))
                    {
                        puts("数量错误。");
                    }
                    else
                    {
                        break;
                    }
                }
                box1 -= tmp;
            }
            else
            {
                while(1)
                {
                    printf("你想要从2号盒子摸多少鹅卵石？");
                    scanf("%d", &tmp);
                    if(!(tmp >= 1 && tmp <= box2))
                    {
                        puts("数量错误。");
                    }
                    else
                    {
                        break;
                    }
                }
                box2 -= tmp;
            }
            printf("现在1号盒子还有%d颗鹅卵石，2号盒子还有%d颗鹅卵石。\n", box1, box2);
            if(box1 == 0 && box2 == 0)
            {
                if(i == 4)
                {
                    break;
                }
                puts("你赢了，再来一局。");
                break;
            }
        }
    }
    puts("高鸟那一直仰望着星空的头颅，现在再也抬不起来了...");
}

void SmallBird()
{
    int i, j, k;
    while(1)
    {
        puts("");
        puts("小鸟会依据你的行为对你进行惩罚，双方均拿到预定的汽水数才可以免除惩罚。");
        puts("你和小鸟之间有一台韦尔奇乐牌汽水机，每次双方可以同时选择是否投放1瓶汽水。");
        puts("每当一方投放1瓶汽水，对方就会获得3瓶汽水。总计进行1000次行为考察，双方初始均拥有1000瓶汽水。");
        puts("");
        int choice1, choice2, choice_aim, choice_last = 1;
        int score1 = 1000, score2 = 1000, score_aim = 1000;
        for(i = 0; i < 1000; i++)
        {
            while(1)
            {
                printf("这一次你要投放(输入1)还是不投放(输入0)汽水？");
                scanf("%d", &choice1);
                // choice1 = 1;
                if(!(choice1 == 1 || choice1 == 0))
                {
                    puts("选择错误。");
                }
                else
                {
                    break;
                }
            }
            read(3, &choice2, sizeof(int));
            choice2 &= 63;
            if(choice2 < 38)
            {
                choice2 = 1;
            }
            else
            {
                choice2 = 0;
            }
            printf("小鸟选择%s投入汽水， 你选择%s投入汽水。\n", choice2 == 1 ? "" : "不", choice1 == 1 ? "" : "不");

            if(choice1 == 1)
            {
                score1 -= 1;
                score2 += 3;
            }
            if(choice2 == 1)
            {
                score1 += 3;
                score2 -= 1;
            }
            printf("现在小鸟有%d瓶汽水，你有%d瓶汽水。\n", score2, score1);

            choice_aim = choice_last;
            choice_last = choice2;
            if(choice_aim == 1)
            {
                score_aim -= 1;
            }
            if(choice2 == 1)
            {
                score_aim += 3;
            }
        }

        printf("本轮考验预定的汽水数为%d。", score_aim);
        if(score2 < score_aim)
        {
            puts("小鸟的汽水数太少了，自私的家伙...");
            puts("小鸟撕开自己的喙，把它变成一张能吞噬任何动物的血盆大口......");
            exit(0);
        }
        if(score1 < score_aim)
        {
            puts("你的汽水数太少了，策略不够完美...");
        }
        else
        {
            break;
        }
    }
    puts("小鸟那可以吞噬一切动物的巨口，现在再也张不开了...");
}

void BigBird()
{
    int i, j, k;
    puts("");
    puts("识别出接下来50组1023位01比特串(一位偶校验纠错码)中唯一的错误信息，防止被大鸟的目灯魅惑！");
    int info[1030] = {};
    int pos, aim, choice, wrong;
    for(i = 0; i < 50; i++)
    {
        for(j = 1; j <= 1023; j++)
        {
            read(3, &info[j], sizeof(int));
            info[j] &= 1;
            // printf("%d ", info[j]);
        }
        // puts("");
        for(j = 0; j < 10; j++)
        {
            pos = pow(2, j);
            aim = pos;
            info[aim] = 0;
            while(1)
            {
                if(pos > 1023)
                {
                    break;
                }
                for(k = 0; k < aim; k++)
                {
                    if(pos + k > 1023)
                    {
                        break;
                    }
                    info[aim] ^= info[pos + k];
                }
                pos += aim + aim;
            }
        }
        read(3, &wrong, sizeof(int));
        wrong = wrong > 0 ? wrong : -wrong;
        wrong = wrong % 1023 + 1;
        info[wrong] = info[wrong] == 1 ? 0 : 1;
        // printf("%d\n", wrong);
        puts("请指出哪一个是错误的：");
        for(j = 1; j <= 1023; j++)
        {
            printf("%d", info[j]);
        }
        // for(j = 1023; j >= 1; j--)
        // {
        //     printf("%d", info[j]);
        // }
        printf("\n>");
        scanf("%d", &choice);
        if(choice != wrong)
        {
            puts("大鸟烧光了自己的羽毛，制成了一盏永不熄灭的明灯......");
            exit(0);
        }
    }
    puts("大鸟那可以看到数百里外的眼睛，现在再也看不见了...");
}

int main()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    open("/dev/urandom", 0, 7);
    puts("很久很久以前，在一片温暖又繁茂的森林里住着三只快乐的鸟儿。");
    puts("为了维持森林的和平，高鸟审判着动物们的罪孽，它的天平能够绝对公正地衡量任何罪恶。");
    puts("小鸟决定用它的喙来惩罚那些犯了错的动物们。");
    puts("长有许多眼睛的大鸟监视着森林寻找入侵者。大鸟的眼睛能看到很远的地方，甚至能看到我们看不见的东西。");
    puts("在嘈杂的哭喊中，在惊恐的尖叫中，有人大声喊道：“是那个怪物！黑暗的森林里有一个可怕的大怪物！”");

    HighBird();
    sleep(1);
    SmallBird();
    sleep(1);
    BigBird();
    sleep(1);
    
    puts("");
    puts("三只鸟————现在成为了一只，四处张望着寻找那个怪物，可没有任何结果。");
    puts("那儿已经什么都没有了，没有动物，没有日月，也没有怪物。只有那只鸟，还有那片黑暗的森林...");
    // puts("TSCTF-J{05cf2a8b9d33-待世界充满了罪孽，这只众生畏惧着的怪鸟就会降临...}");
    system("cat flag");
    return 0;
}