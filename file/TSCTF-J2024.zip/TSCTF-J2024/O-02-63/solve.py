from pwn import *

# context.log_level = 'debug'
# p = process('./O-02-63')
p = remote('challenges.hazmat.buptmerak.cn', 20029)

# HighBird
for i in range(5):
    box1 = 5
    box2 = 0
    p.sendlineafter('？'.encode(), b'5')
    box2 = int(p.recvline().split('入'.encode())[1].split('颗'.encode())[0].decode())
    p.sendlineafter('？'.encode(), b'2')
    p.sendlineafter('？'.encode(), b'1')

    while 1:
        p.recvline()
        p.recvuntil('有'.encode())
        box1 = int(p.recvuntil('颗'.encode()).replace('颗'.encode(), b'').decode())
        p.recvuntil('有'.encode())
        box2 = int(p.recvuntil('颗'.encode()).replace('颗'.encode(), b'').decode())

        if box1 > box2:
            p.sendlineafter('？'.encode(), b'1')
            p.sendlineafter('？'.encode(), str(box1 - box2).encode())
        else:
            p.sendlineafter('？'.encode(), b'2')
            p.sendlineafter('？'.encode(), str(box2 - box1).encode())
        
        p.recvuntil('有'.encode())
        box1 = int(p.recvuntil('颗'.encode()).replace('颗'.encode(), b'').decode())
        p.recvuntil('有'.encode())
        box2 = int(p.recvuntil('颗'.encode()).replace('颗'.encode(), b'').decode())
        if box1 == 0 and box2 == 0:
            break

# SmallBird
last = 1
for i in range(1000):
    p.sendlineafter('？'.encode(), str(last).encode())
    recv = p.recvuntil('，'.encode())
    if '不'.encode() in recv:
        last = 0
    else:
        last = 1

# BigBird
for i in range(50):
    p.recvuntil('：'.encode())
    bitdata = [0]
    bitdata += list(p.recvuntil(b'>').replace(b'>', b'').replace(b'\n', b'').replace(b'1', b'\x01').replace(b'0', b'\x00'))
    wrong = 0
    for j in range(10):
        check = 0
        pos = pow(2, j)
        aim = pos
        while 1:
            if pos > 1023:
                break
            for k in range(aim):
                if pos + k > 1023:
                    break
                check ^= bitdata[pos + k]
            pos += aim + aim
        if check == 1:
            wrong += aim
    p.sendline(str(wrong).encode())

p.interactive()