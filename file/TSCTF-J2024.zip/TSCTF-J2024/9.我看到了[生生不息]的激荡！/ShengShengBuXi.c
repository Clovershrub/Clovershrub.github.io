#include <stdlib.h>
#include <stdio.h>

struct Node{
    char* str;
    int len;
};

int is_Note = 1, is_Check = 1, index = 0;
struct Node List[100] = {};

void my_puts(char* s)
{
    write(1, s, strlen(s));
    write(1, "\n", 1);
}

void my_read(unsigned int fd, char* buf, size_t count)
{
    size_t i;
    for(i = 0; i < count; i++)
    {
        read(0, &buf[i], 1);
        if(buf[i] == '\n')
        {
            return;
        }
    }
}

void menu()
{
    my_puts("What do you want to do?");
    my_puts("1.Earn some \"dao\".");
    my_puts("2.Buy some necessity.");
    my_puts("3.Note a package of \"dao\".");
    my_puts("4.Check a package of \"dao\".");
    my_puts("Your choice:");
}

void Earn()
{
    my_puts("How many \"dao\" have you earned?");
    char buffer[20] = {};
    int size;
    memset(buffer, 0, 15);
    my_read(0, buffer, 10);
    size = atoi(buffer);
    if(!(size >= 0x500 && size <= 0x1000))
    {
        my_puts("No way!");
        return;
    }
    List[index].str = malloc(size);
    List[index].len = size;
    index++;
}

void Buy()
{
    my_puts("Which package of \"dao\" do you want to use?");
    char buffer[20] = {};
    int id;
    memset(buffer, 0, 15);
    my_read(0, buffer, 10);
    id = atoi(buffer);
    if((!(id >= 0 && id < 16)) || (!(List[id].str)))
    {
        my_puts("No way!");
        return;
    }
    free(List[id].str);
}

void Note()
{
    if(!is_Note)
    {
        my_puts("You have noted before.");
        return;
    }
    is_Note = 0;
    my_puts("Which package of \"dao\" do you want to note?");
    char buffer[20] = {};
    int id;
    memset(buffer, 0, 15);
    my_read(0, buffer, 10);
    id = atoi(buffer);
    if((!(id >= 0 && id < 16)) || (!(List[id].str)))
    {
        my_puts("No way!");
        return;
    }
    my_puts("Now, begin.");
    my_read(0, List[id].str, List[id].len);
}

void Check()
{
    if(!is_Check)
    {
        my_puts("You have checked before.");
        return;
    }
    is_Check = 0;
    my_puts("Which package of \"dao\" do you want to check?");
    char buffer[20] = {};
    int id;
    memset(buffer, 0, 15);
    my_read(0, buffer, 10);
    id = atoi(buffer);
    if((!(id >= 0 && id < 16)) || (!(List[id].str)))
    {
        my_puts("No way!");
        return;
    }
    write(1, List[id].str, List[id].len);
}

int main()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    // init();

    my_puts("This time, how could you be able to kill \"Tian Long\"?");
    int choice;
    char buffer[20];
    while(1)
    {
        menu();
        memset(buffer, 0, 15);
        my_read(0, buffer, 10);
        choice = atoi(buffer);
        switch(choice)
        {
            case 1:
                Earn();
                break;
            case 2:
                Buy();
                break;
            case 3:
                Note();
                break;
            case 4:
                Check();
                break;
            default:
                my_puts("No, it's not a good choice!");
                return 0;
        }
    }
    return 0;
}