import socket
import os
import uuid
import base64
import random
import time
from Cryptodome.Util.number import *
from Cryptodome.Cipher import AES, DES, ARC4, ARC2

bullets = ["第一弹————贯穿".encode(), "第二弹————精准".encode(), "第三弹————摄魂".encode(), "第四弹————残酷".encode(), "第五弹————噤声".encode(), "第六弹————倾泻".encode(), "第七弹————绝望".encode()]
story = [
    "某个猎人从恶魔那里获得一杆猎枪，但恶魔提出了一个狡猾的契约————这杆猎枪所射出的最后一颗子弹会刺穿他心爱之人的胸膛。".encode(),
    "猎人听到这儿，便将他爱着的人们一一射杀。然后，他告诉那个恶魔：“这枚神奇的子弹真的能命中我所说的任何目标！”".encode(),
    "子弹已经打空了，猎人开始在不同的世界中辗转旅行。他有时会帮助那些需要帮助的人们，亦或是与邪恶作斗争。".encode(),
    "但这都是他一时冲动的结果，而绝非出自他的善意。有些人将他称作“正义的猎人”，而另一些人则称他为“血腥的射手”。他早已忘记诸如爱与快乐之类的积极事物，现在，他只对将死之物感兴趣。".encode(),
    "有一天，猎人发现那个恶魔不再徘徊在他的身边。他试着追寻原因，然后他突然意识到自己的灵魂已经堕落到地狱了————也就是说，契约已经达成了，恶魔自然便离开了。".encode(),
    "这位射手————同时也是一个恶魔，继续扣动着它的扳机，猎取他人的灵魂。正如那个恶魔所说，子弹会刺穿它爱着的人们。永远...永远...".encode(),
    "猎人的心早已被那枚能够命中任何目标的魔弹刺穿了。摒弃了所有所爱之人后，最后所爱的人也就只有自己啊。".encode()
]
encryptions = ["base64", "base64、XOR", "base64、XOR、AES-ECB", "base64、XOR、AES-ECB、DES-ECB", "base64、XOR、AES-ECB、DES-ECB、RC4", "base64、XOR、AES-ECB、DES-ECB、RC4、RC2-ECB"]

def Enc_base64(plain:bytes):
    cipher = base64.b64encode(plain)

    assert type(cipher) == bytes
    return cipher

def Enc_XOR(plain:bytes, key:bytes):
    cipher = []
    for i in range(len(plain)):
        cipher.append(b'%c' % (plain[i] ^ key[i % len(key)]))
    cipher = b''.join(cipher)
 
    assert type(cipher) == bytes
    return cipher

def Enc_AES(plain:bytes, key:bytes):
    while len(plain) % 16 != 0:
        plain += b'\x00'
    aes = AES.new(key, AES.MODE_ECB)
    cipher = aes.encrypt(plain)

    assert type(cipher) == bytes
    return cipher

def Enc_DES(plain:bytes, key:bytes):
    while len(plain) % 8 != 0:
        plain += b'\x00'
    des = DES.new(key, DES.MODE_ECB)
    cipher = des.encrypt(plain)

    assert type(cipher) == bytes
    return cipher

def Enc_RC4(plain:bytes, key:bytes):
    rc4 = ARC4.new(key)
    cipher = rc4.encrypt(plain)

    assert type(cipher) == bytes
    return cipher

def Enc_RC2(plain:bytes, key:bytes):
    while len(plain) % 8 != 0:
        plain += b'\x00'
    rc2 = ARC2.new(key, ARC2.MODE_ECB)
    cipher = rc2.encrypt(plain)

    assert type(cipher) == bytes
    return cipher

def GetKey(len):
    while 1:
        key = os.urandom(len)
        if b'\x00' not in key:
            break
    return key

def GetCipher(times):
    plain = str(uuid.uuid4()).encode()
    # connect.sendall(plain + b"\n")
    data = plain

    XOR_key = GetKey(16)
    AES_key = GetKey(16)
    DES_key = GetKey(8)
    RC4_key = GetKey(8)
    RC2_key = GetKey(8)
    for i in range(min(10, 2 * times)):
        enc = random.randint(0, times-1)
        match enc:
            case 0:
                data = Enc_base64(data)
            case 1:
                data = Enc_XOR(data, XOR_key)
            case 2:
                data = Enc_AES(data, AES_key)
            case 3:
                data = Enc_DES(data, DES_key)
            case 4:
                data = Enc_RC4(data, RC4_key)
            case 5:
                data = Enc_RC2(data, RC2_key)
            case other:
                raise EOFError

    cipher = base64.b64encode(data)
    return plain, cipher, bytes_to_long(XOR_key), bytes_to_long(AES_key), bytes_to_long(DES_key), bytes_to_long(RC4_key), bytes_to_long(RC2_key)

def main():
    connect.sendall("一个恶魔最终想要的，就是“绝望”。\n".encode())
    connect.sendall("绝望会使人意志消沉，失去前进的决心。当一个人感受到没有什么能驱使他继续前进时，他的灵魂就已经死了，然后堕入地狱————恶魔的领域。这就是人们常说的：“把你的灵魂出卖给恶魔。”所以，恶魔最喜欢窥伺那些深陷绝望之中的人们，而不是专注于诸如谋杀之类的简单行径。\n".encode())
    for i in range(6):
        connect.sendall(b'\033[1;32m' + bullets[i] + b'\033[0m\n')
        connect.sendall(f"这一颗子弹总计进行过{min(10, 2*(i+1))}次加密，每种加密次数未知、顺序未知，包括{encryptions[i]}。\n".encode())
        if i >= 2:
            connect.sendall("其中AES加密前会将数据用b'\\x00'在后方补齐至16字节的倍数。".encode())
        if i >= 3:
            connect.sendall("DES加密前会将数据用b'\\x00'在后方补齐至8字节的倍数。".encode())
        if i >= 5:
            connect.sendall("RC2加密前会将数据用b'\\x00'在后方补齐至8字节的倍数。".encode())
        if i >= 2:
            connect.sendall(b"\n")
        
        connect.sendall("其加密并进行base64编码后为：".encode())
        plain, cipher, XOR_key, AES_key, DES_key, RC4_key, RC2_key = GetCipher(i+1)
        connect.sendall(cipher + b"\n")
        if i >= 1:
            connect.sendall(f"注意XOR加密使用秘钥为{hex(XOR_key)}。".encode())
        if i >= 2:
            connect.sendall(f"AES加密使用秘钥为{hex(AES_key)}。".encode())
        if i >= 3:
            connect.sendall(f"DES加密使用秘钥为{hex(DES_key)}。".encode())
        if i >= 4:
            connect.sendall(f"RC4加密使用秘钥为{hex(RC4_key)}。".encode())
        if i >= 5:
            connect.sendall(f"RC2加密使用秘钥为{hex(RC2_key)}。".encode())
        connect.sendall(b"\n")

        connect.sendall("请尝试破解这颗子弹：".encode())
        content = connect.recv(1024).strip()
        if content != plain:
            connect.sendall("\033[34m就跟所有同恶魔打交道的人一样，与魔弹射手的交易绝不会以和平的方式结束。\033[0m\n".encode())
            raise EOFError
        
        connect.sendall(b"\n")
        connect.sendall(b'\033[1;31m' + story[i] + b'\033[0m\n')
        connect.sendall(b"\n")
        time.sleep(1)

    connect.sendall(b'\033[1;32m' + bullets[6] + b'\033[0m\n')
    connect.sendall("这一颗子弹%^x!&*Ak$!@a...包括i!bu%$&*~...49A?z......\n".encode())
    connect.sendall("其进行u;Y`编码后为：".encode())
    plain = str(uuid.uuid4()).encode()
    cipher = Enc_base64(plain)
    cipher = Enc_base64(cipher)
    cipher = Enc_base64(cipher)
    connect.sendall(cipher + b"\n")
    XOR_key = bytes_to_long(GetKey(16))
    AES_key = bytes_to_long(GetKey(16))
    DES_key = bytes_to_long(GetKey(8))
    RC4_key = bytes_to_long(GetKey(8))
    RC2_key = bytes_to_long(GetKey(8))
    SM4_key = bytes_to_long(GetKey(16))
    connect.sendall(f"注意@af加密使用秘钥为{hex(XOR_key)}。".encode())
    connect.sendall(f"#p9加密使用秘钥为{hex(DES_key)}。".encode())
    connect.sendall(f"^x!加密使用秘钥为{hex(RC4_key)}。".encode())
    connect.sendall(f"%*z加密使用秘钥为{hex(AES_key)}。".encode())
    connect.sendall(f"i6h加密使用秘钥为{hex(RC2_key)}。".encode())
    connect.sendall(f"?l\加密使用秘钥为{hex(SM4_key)}。".encode())
    connect.sendall(b"\n")
    connect.sendall("请尝试破解这颗子弹：".encode())
    content = connect.recv(1024).strip()
    if content != plain:
        connect.sendall("\033[34m就跟所有同恶魔打交道的人一样，与魔弹射手的交易绝不会以和平的方式结束。\033[0m\n".encode())
        raise EOFError
    
    connect.sendall(b"\n")
    connect.sendall(b'\033[1;31m' + story[6] + b'\033[0m\n')
    connect.sendall(b"\n")
    time.sleep(1)

    flag = open('flag', 'r').read().encode()
    connect.sendall(flag)
    raise EOFError

connect:socket
if __name__ == '__main__':
    os.system("echo $FLAG > ./flag")
    while 1:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(('0.0.0.0', 9999))
            s.listen()
            connect, addr = s.accept()
            main()
        except EOFError:
            connect.close()
        else:
            pass