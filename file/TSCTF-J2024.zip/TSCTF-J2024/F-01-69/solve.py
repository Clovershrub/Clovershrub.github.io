import base64
from Cryptodome.Util.number import *
from Cryptodome.Cipher import AES, DES, ARC4, ARC2
from pwn import *

def Dec_base64(cipher:bytes):
    plain = base64.b64decode(cipher)

    assert type(plain) == bytes
    return plain

def Dec_XOR(cipher:bytes, key:bytes):
    plain = []
    for i in range(len(cipher)):
        plain.append(b'%c' % (cipher[i] ^ key[i % len(key)]))
    plain = b''.join(plain)
 
    assert type(plain) == bytes
    return plain

def Dec_AES(cipher:bytes, key:bytes):
    while len(cipher) % 16 != 0:
        cipher += b'\x00'
    aes = AES.new(key, AES.MODE_ECB)
    plain = aes.decrypt(cipher)

    assert type(plain) == bytes
    return plain

def Dec_DES(cipher:bytes, key:bytes):
    while len(cipher) % 8 != 0:
        cipher += b'\x00'
    des = DES.new(key, DES.MODE_ECB)
    plain = des.decrypt(cipher)

    assert type(plain) == bytes
    return plain

def Dec_RC4(cipher:bytes, key:bytes):
    rc4 = ARC4.new(key)
    plain = rc4.decrypt(cipher)

    assert type(plain) == bytes
    return plain

def Dec_RC2(cipher:bytes, key:bytes):
    while len(cipher) % 8 != 0:
        cipher += b'\x00'
    rc2 = ARC2.new(key, ARC2.MODE_ECB)
    plain = rc2.decrypt(cipher)

    assert type(plain) == bytes
    return plain

def dfs(times, count, cipher):
    global is_success
    if count == 0:
        for i in range(36):
            if not (cipher[i] >= 48 and cipher[i] <= 57 or cipher[i] >= 97 and cipher[i] <= 102 or cipher[i] == 45):
                return
        print(cipher[:36])
        p.send(cipher[:36])
        print("")
        is_success = 1
        return

    if times >= 1:
        # print(1, end = '')
        try:
            newcipher = Dec_base64(cipher)
            dfs(times, count-1, newcipher)
            if is_success == 1:
                return
        except:
            pass
    if times >= 2:
        # print(2, end = '')
        try:
            newcipher = Dec_XOR(cipher, XOR_key)
            dfs(times, count-1, newcipher)
            if is_success == 1:
                return
        except:
            pass
    if times >= 3:
        # print(3, end = '')
        try:
            newcipher = Dec_AES(cipher, AES_key)
            dfs(times, count-1, newcipher)
            if is_success == 1:
                return
        except:
            pass
    if times >= 4:
        # print(4, end = '')
        try:
            newcipher = Dec_DES(cipher, DES_key)
            dfs(times, count-1, newcipher)
            if is_success == 1:
                return
        except:
            pass
    if times >= 5:
        # print(5, end = '')
        try:
            newcipher = Dec_RC4(cipher, RC4_key)
            dfs(times, count-1, newcipher)
            if is_success == 1:
                return
        except:
            pass
    if times >= 6:
        # print(6, end = '' )
        try:
            newcipher = Dec_RC2(cipher, RC2_key)
            dfs(times, count-1, newcipher)
            if is_success == 1:
                return
        except:
            pass

# context.log_level = 'debug'
p = remote('challenges.hazmat.buptmerak.cn', 20171)
# p = remote('127.0.0.1', 888)

XOR_key = b''
AES_key = b''
DES_key = b''
RC4_key = b''
RC2_key = b''
is_success = 0

for times in range(6):
    p.recvuntil('编码后为：'.encode())
    cipher = p.recvline().strip()
    print(cipher)
    KeyData = p.recvline().strip().split('。'.encode())
    try:
        XOR_key = long_to_bytes(int(KeyData[0].split(b'0x')[1].decode(), 16))
        AES_key = long_to_bytes(int(KeyData[1].split(b'0x')[1].decode(), 16))
        DES_key = long_to_bytes(int(KeyData[2].split(b'0x')[1].decode(), 16))
        RC4_key = long_to_bytes(int(KeyData[3].split(b'0x')[1].decode(), 16))
        RC2_key = long_to_bytes(int(KeyData[4].split(b'0x')[1].decode(), 16))
    except:
        pass
    print(XOR_key, AES_key, DES_key, RC4_key, RC2_key)
    p.recvuntil('请尝试破解这颗子弹：'.encode())

    cipher = Dec_base64(cipher)
    is_success = 0
    dfs(min(10, 2*(times+1)), min(10, 2*(times+1)), cipher)

p.recvuntil('编码后为：'.encode())
cipher = p.recvline().strip()
print(cipher)
cipher = Dec_base64(cipher)
cipher = Dec_base64(cipher)
cipher = Dec_base64(cipher)
p.recvuntil('请尝试破解这颗子弹：'.encode())
print(cipher)
p.send(cipher)

p.interactive()