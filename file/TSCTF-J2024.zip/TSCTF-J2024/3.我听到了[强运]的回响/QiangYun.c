#include <stdlib.h>
#include <stdio.h>

int i = 0;

int main()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);

    int randint[5] = {};
    int xor[5] = {};
    char fmt[0x40];
    int j = 0;
    int guess[5] = {};

    memset(fmt, 0, 0x40);
    open("/dev/urandom", 0, 7);
    read(3, randint, 5 * sizeof(int));
    // for(j = 0; j < 5; j++)
    // {
    //     printf("%x ", randint[j]);
    // }
    // puts("");
    puts("I have heard the call of \"QiangYun\", is that yours?");

    read(0, fmt, 0x40);
    printf("Seriously? ");
    printf(fmt);
    printf("Let's check...\n");

    for(j = 0; j < 5; j++)
    {
        scanf("%d", &guess[j]);
    }
    read(3, xor, 5 * sizeof(int));
    for(; i < 5; i++)
    {
        randint[i] ^= xor[i];
        if(randint[i] != guess[i])
        {
            puts("emmm...it doesn't seem like...");
            return 0;
        }
    }
    system("/bin/sh");
    return 0;
}