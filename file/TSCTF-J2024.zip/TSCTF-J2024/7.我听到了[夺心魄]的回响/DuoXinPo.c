#include <stdlib.h>
#include <stdio.h>

struct Node{
    char* str;
    int len;
};

struct Node List[100] = {};

void menu()
{
    puts("How can you control me?");
    puts("1.Create an abstract.");
    puts("2.Delete an abstract.");
    puts("3.Change an abstract.");
    puts("4.Browse an abstract.");
    puts("Your choice:");
}

void Create()
{
    int id, size;
    puts("Give me the id.");
    scanf("%d", &id);
    if(!(id >= 0 && id < 50))
    {
        puts("No way!");
        return;
    }
    if(List[id].str)
    {
        puts("No way!");
        return;
    }
    puts("How long are you going to write?");
    scanf("%d", &size);
    if(!(size >= 0x500 && size < 0x1000))
    {
        puts("No way!");
        return;
    }
    List[id].str = malloc(size);
    List[id].len = size;
    puts("Now, begin.");
    read(0, List[id].str, List[id].len);
}

void Delete()
{
    int id;
    puts("Which one do you want to delete?");
    scanf("%d", &id);
    if(!(id >= 0 && id < 50))
    {
        puts("No way!");
        return;
    }
    if(!(List[id].str))
    {
        puts("No way!");
        return;
    }
    free(List[id].str);
}

void Change()
{
    int id;
    puts("Which one do you want to change?");
    scanf("%d", &id);
    if(!(id >= 0 && id < 50))
    {
        puts("No way!");
        return;
    }
    if(!(List[id].str))
    {
        puts("No way!");
        return;
    }
    puts("Now, begin.");
    read(0, List[id].str, List[id].len);
}

void Browse()
{
    int id;
    puts("Which one do you want to see?");
    scanf("%d", &id);
    if(!(id >= 0 && id < 50))
    {
        puts("No way!");
        return;
    }
    if(!List[id].str)
    {
        puts("No way!");
        return;
    }
    puts(List[id].str);
}

int main()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);

    puts("I have heard the call of \"DuoXinPo\", is that yours?");
    int choice;
    while(1)
    {
        menu();
        scanf("%d", &choice);
        switch(choice)
        {
            case 1:
                Create();
                break;
            case 2:
                Delete();
                break;
            case 3:
                Change();
                break;
            case 4:
                Browse();
                break;
            default:
                puts("emmm...it doesn't seem like...");
                return 0;
        }
    }
    return 0;
}