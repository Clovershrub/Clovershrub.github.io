#include <stdlib.h>
#include <stdio.h>

char* RecordList[100] = {};

void menu()
{
    puts("I have changed somthing about me.");
    puts("How do you feel now?");
    puts("1.Create a record.");
    puts("2.Delete a record.");
    puts("3.Change a record.");
    puts("4.Browse a record.");
    puts("Your choice:");
}

void Create()
{
    int size, i;
    puts("How long are you going to write?");
    scanf("%d", &size);
    if(!(size >= 0 && size <= 0x80))
    {
        puts("No way!");
        return;
    }
    for(i = 0; i < 50; i++)
    {
        if(!RecordList[i])
        {
            RecordList[i] = malloc(size);
            break;
        }
    }
}

void Delete()
{
    int id;
    puts("Which one do you want to delete?");
    scanf("%d", &id);
    if(!(id >= 0 && id < 50))
    {
        puts("No way!");
        return;
    }
    if(!(RecordList[id]))
    {
        puts("No way!");
        return;
    }
    free(RecordList[id]);
    RecordList[id] = 0;
}

void Change()
{
    int id;
    puts("Which one do you want to change?");
    scanf("%d", &id);
    if(!(id >= 0 && id < 50))
    {
        puts("No way!");
        return;
    }
    if(!(RecordList[id]))
    {
        puts("No way!");
        return;
    }
    puts("Now, begin.");
    read(0, RecordList[id], 0x100);
}

void Browse()
{
    int id;
    puts("Which one do you want to see?");
    scanf("%d", &id);
    puts("Request accepted. The result will be given in 7 days.");
}

int main()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);

    puts("I have heard the call of \"ShuangShengHua\", is that yours?");
    puts("Touch me, and let me see your power.");
    int choice;
    while(1)
    {
        menu();
        scanf("%d", &choice);
        switch(choice)
        {
            case 1:
                Create();
                break;
            case 2:
                Delete();
                break;
            case 3:
                Change();
                break;
            case 4:
                Browse();
                break;
            default:
                puts("emmm...it doesn't seem like...");
                return 0;
        }
    }
    return 0;
}