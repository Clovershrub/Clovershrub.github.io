#include <stdio.h>

void magic()
{
    asm("pop %rdi");
    asm("ret");
}

void vuln()
{
    char buf[0x30];
    printf("I have heard the call of \"TiZui\", is that yours?");
    read(0, buf, 0x40);
    printf("%s, right? One more time, is that yours?", buf);
    read(0, buf, 0x40);
    return;
}

int main()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    system("clear");

    vuln();
    puts("emmm...it doesn't seem like...");
    return 0;
}