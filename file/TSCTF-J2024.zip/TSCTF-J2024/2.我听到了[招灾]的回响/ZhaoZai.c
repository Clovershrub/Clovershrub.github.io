#include <stdlib.h>
#include <stdio.h>

void vuln()
{
    char buf[0x20];
    char i;

    puts("I have heard the call of \"ZhaoZai\", is that yours?");
    i = 0;
    gets(buf);
    for(; i <= 'z'; i++)
    {
        buf[i] ^= 23;
    }
    return;
}

int main()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);

    vuln();
    puts("emmm...it doesn't seem like...");
    return 0;
}