import idc

st = 
end = 

def next_instr(addr):
    return addr + get_item_size(addr)                   #获取指令的大小，此函数用于迭代至下一条指令
 
addr = st
while(addr<end):
    next = next_instr(addr)
    if "ds:dword_603054" in GetDisasm(addr):            #对扰乱我们的变量查找，GetDisasm()函数获取汇编码
        while(True):
            addr = next
            next = next_instr(addr)
            if "jnz" in GetDisasm(addr):                #对于x64来讲，jnz的指令是5个字节，而jmp是4个
                dest = get_operand_value(addr, 0)       #获取机器码的操作数
                idc.patch_byte(addr, 0xe9)
                idc.patch_byte(addr+5, 0x90)
                offset = dest - (addr + 5)
                idc.patch_dword(addr + 1, offset)
                print("patch bcf: 0x%x"%addr)
                addr = next
                break
    else:
        addr = next